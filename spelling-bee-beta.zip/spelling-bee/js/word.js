
function showWord(word) {
  const wordDisplay = document.getElementById('wordDisplay');
  wordDisplay.textContent = word;

  const phraseDisplay = document.getElementById('phraseDisplay');
  phraseDisplay.textContent = 'The word is:';
}

    document.addEventListener('DOMContentLoaded', function() {
      const counterElement = document.getElementById('counter');
      const randomNumberButton = document.getElementById('randomNumber');
      
      randomNumberButton.addEventListener('click', function() {
        const randomNumber = Math.floor(Math.random() * 60) + 1; // Generate a random number between 1 and 60
        counterElement.textContent = randomNumber;
    
        setTimeout(function() {
          counterElement.textContent = ''; // Clear the content after 3 seconds
        }, 1000); // 1 seconds
      });
    });